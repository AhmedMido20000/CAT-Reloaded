﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Configuration;

namespace Task_cat
{
    internal class Program
    {
        static string Filepath = "users data.txt";
        static public void Main(string[] args)
        {
            Console.WriteLine("Welcome to little program");
            Console.WriteLine("Chose 1 if want register new user");
            Console.WriteLine("chose 2 if want login");
            string choice = Console.ReadLine();
            if (choice == "1")
                Register();
            else if (choice == "2")
                Login();
        }
        static public void Register()
        {
            Console.WriteLine("Enter your username: ");
            string username = Console.ReadLine();
            Console.WriteLine("Enter your email: ");
            string email = Console.ReadLine();
            string password;
            string password2;
            while (true)
            {
                Console.WriteLine("Enter your password(must be at least 8 characters): ");
                password = Console.ReadLine();
                if (password.Length >= 8)
                {   
                        Console.WriteLine("Confirm password");
                        password2 = Console.ReadLine();
                        if (password == password2)
                            break;
                        else
                            Console.WriteLine("Passord incorrect\n" + "please try agin");   
                }  
                else
                {
                    Console.WriteLine("password less than 8 characters\n" + "please try agin");
                }
            }
            string userdata = $"{username},{email},{password}\n";
            FileStream fs = new FileStream(Filepath, FileMode.Append, FileAccess.Write);
            StreamWriter write = new StreamWriter(fs);
            write.Write(userdata);
            write.Flush();
            fs.Close();
            Console.WriteLine("Register is successful");
        }
        static void Login()
        {
             Console.WriteLine("Enter your email: ");
             string email = Console.ReadLine();
             Console.WriteLine("Enter your password: ");
             string password = Console.ReadLine();
             bool loginsuccessful = false;
            if (File.Exists(Filepath))
            {
                StreamReader reader = new StreamReader(Filepath);
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] userdetails = line.Split(',');
                    if (userdetails.Length == 3)
                    {
                        string savedemail = userdetails[1].Trim();
                        string savedpaasword = userdetails[2].Trim();
                        if (savedemail == email && savedpaasword == password)
                        {
                            Console.WriteLine("Welcome:" + userdetails[0]);
                            loginsuccessful = true;
                            break;
                        }
                    }
                }
                if (!loginsuccessful)
                    Console.WriteLine("email or password incorrect");
            }
            else
                Console.WriteLine("No registered users found\n" + "please register first");
        }
}   }
