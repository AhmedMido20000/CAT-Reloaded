﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Task_cat2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[]arr = {"++","++","--","++"};
            int Finalresult=result(arr);
            Console.WriteLine(Finalresult);
        }
        static int result(string[]arr)
        {
            int count = 0;
            for(int i=0;i<arr.Length;i++)
            {
                if (arr[i] == "++")
                    count++;
                else if (arr[i] == "--")
                    count--;
            }
            return count;
        }
    }
}
